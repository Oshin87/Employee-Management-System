package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.connection.Connector;
import com.entity.Employee;

public class EmployeeDao {
	public static boolean register(Employee emp) throws ClassNotFoundException, SQLException {
		Connection cn = Connector.createconnection();
		String query="insert into employee values(?,?,?,?,?,?,?)";
		
		PreparedStatement pp = cn.prepareStatement(query);
		pp.setString(1, emp.getId());
		pp.setString(2, emp.getFname());
		pp.setString(3, emp.getLname());
		pp.setString(4, emp.getUsername());
		pp.setString(5, emp.getPassword());
		pp.setString(6, emp.getAddress());
		pp.setString(7, emp.getContact());
		

		return pp.execute();
		
		
		
	}

}
