package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connector {
	public static Connection createconnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url= "jdbc:mysql://localhost:3306/Employee_management";
		String username="root";
		String password="2003";
		
		Connection cn = DriverManager.getConnection(url,username,password);
		
		return cn;
		
	}




}
