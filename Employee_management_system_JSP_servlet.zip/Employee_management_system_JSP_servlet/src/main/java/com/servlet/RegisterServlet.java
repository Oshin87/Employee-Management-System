package com.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import com.DAO.EmployeeDao;
import com.entity.Employee;


public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id= request.getParameter("id");
		String fname= request.getParameter("fname");
		String lname= request.getParameter("lname");
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		String address= request.getParameter("address");
		String contact= request.getParameter("contact");
		
		
		Employee emp = new Employee();
		emp.setId(id);
		emp.setFname(fname);
		emp.setLname(lname);
		emp.setUsername(username);
		emp.setPassword(password);
		emp.setAddress(address);
		emp.setContact(contact);

		try {
			EmployeeDao.register(emp);
			RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
			rd.forward(request, response);
			
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	

}
